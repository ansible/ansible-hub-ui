========================================
Ansible Network Collection Release Notes
========================================

.. contents:: Topics


v1.2.0
======

Release Summary
---------------

- Released 1.2.0 with updated docs.

v1.1.0
======

Minor Changes
-------------

- Add platform agnostic resource manager role (https://github.com/ansible-collections/ansible.network/issues/13).

v1.0.1
======

Release Summary
---------------
- Updated README.md and regenerated documentation.

v1.0.0
======

Release Summary
---------------

- Released 1.0.0 with updated changelog.
